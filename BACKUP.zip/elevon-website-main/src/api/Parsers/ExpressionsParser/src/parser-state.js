import contains from "./contains";
import { binaryInstruction, IARRAY, IENDSTATEMENT, IEXPR, IFUNCALL, IFUNDEF, IMEMBER, Instruction, INUMBER, IVAR, IVARNAME, ternaryInstruction, unaryInstruction } from "./instruction";
import { TBRACKET, TCOMMA, TEOF, TNAME, TNUMBER, TOP, TPAREN, TSEMICOLON, TSTRING } from "./token";

export function ParserState(parser, tokenStream, options) {
    this.parser = parser;
    this.tokens = tokenStream;
    this.current = null;
    this.nextToken = null;
    this.next();
    this.savedCurrent = null;
    this.savedNextToken = null;
    this.allowMemberAccess = options.allowMemberAccess !== false;
}

ParserState.prototype.next = function () {
    this.current = this.nextToken;
    return (this.nextToken = this.tokens.next());
};

ParserState.prototype.tokenMatches = function (token, value) {
    if (typeof value === "undefined") {
        return true;
    } else if (Array.isArray(value)) {
        return contains(value, token.value);
    } else if (typeof value === "function") {
        return value(token);
    } else {
        return token.value === value;
    }
};

ParserState.prototype.save = function () {
    this.savedCurrent = this.current;
    this.savedNextToken = this.nextToken;
    this.tokens.save();
};

ParserState.prototype.restore = function () {
    this.tokens.restore();
    this.current = this.savedCurrent;
    this.nextToken = this.savedNextToken;
};

ParserState.prototype.accept = function (type, value) {
    if (this.nextToken.type === type && this.tokenMatches(this.nextToken, value)) {
        this.next();
        return true;
    }
    return false;
};

ParserState.prototype.expect = function (type, value) {
    if (!this.accept(type, value)) {
        var coords = this.tokens.getCoordinates();
        throw new Error("parse error [" + coords.line + ":" + coords.column + "]: Expected " + (value || type));
    }
};

ParserState.prototype.parseAtom = function (instr) {
    var { unaryOps } = this.tokens;
    function isPrefixOperator(token) {
        return token.value in unaryOps;
    }

    if (this.accept(TNAME) || this.accept(TOP, isPrefixOperator)) {
        instr.push(new Instruction(IVAR, this.current.value));
    } else if (this.accept(TNUMBER)) {
        instr.push(new Instruction(INUMBER, this.current.value));
    } else if (this.accept(TSTRING)) {
        instr.push(new Instruction(INUMBER, this.current.value));
    } else if (this.accept(TPAREN, "(")) {
        this.parseExpression(instr);
        this.expect(TPAREN, ")");
    } else if (this.accept(TBRACKET, "[")) {
        if (this.accept(TBRACKET, "]")) {
            instr.push(new Instruction(IARRAY, 0));
        } else {
            var argCount = this.parseArrayList(instr);
            instr.push(new Instruction(IARRAY, argCount));
        }
    } else {
        throw new Error("unexpected " + this.nextToken);
    }
};

ParserState.prototype.parseExpression = function (instr) {
    var exprInstr = [];
    if (this.parseUntilEndStatement(instr, exprInstr)) {
        return;
    }
    this.parseVariableAssignmentExpression(exprInstr);
    if (this.parseUntilEndStatement(instr, exprInstr)) {
        return;
    }
    this.pushExpression(instr, exprInstr);
};

ParserState.prototype.pushExpression = function (instr, exprInstr) {
    for (var i = 0, len = exprInstr.length; i < len; i++) {
        instr.push(exprInstr[i]);
    }
};

ParserState.prototype.parseUntilEndStatement = function (instr, exprInstr) {
    if (!this.accept(TSEMICOLON)) return false;
    if (this.nextToken && this.nextToken.type !== TEOF && !(this.nextToken.type === TPAREN && this.nextToken.value === ")")) {
        exprInstr.push(new Instruction(IENDSTATEMENT));
    }
    if (this.nextToken.type !== TEOF) {
        this.parseExpression(exprInstr);
    }
    instr.push(new Instruction(IEXPR, exprInstr));
    return true;
};

ParserState.prototype.parseArrayList = function (instr) {
    var argCount = 0;

    while (!this.accept(TBRACKET, "]")) {
        this.parseExpression(instr);
        ++argCount;
        while (this.accept(TCOMMA)) {
            this.parseExpression(instr);
            ++argCount;
        }
    }

    return argCount;
};

ParserState.prototype.parseVariableAssignmentExpression = function (instr) {
    this.parseConditionalExpression(instr);
    while (this.accept(TOP, "=")) {
        var varName = instr.pop();
        var varValue = [];
        var lastInstrIndex = instr.length - 1;
        if (varName.type === IFUNCALL) {
            if (!this.tokens.isOperatorEnabled("()=")) {
                throw new Error("function definition is not permitted");
            }
            for (var i = 0, len = varName.value + 1; i < len; i++) {
                var index = lastInstrIndex - i;
                if (instr[index].type === IVAR) {
                    instr[index] = new Instruction(IVARNAME, instr[index].value);
                }
            }
            this.parseVariableAssignmentExpression(varValue);
            instr.push(new Instruction(IEXPR, varValue));
            instr.push(new Instruction(IFUNDEF, varName.value));
            continue;
        }
        if (varName.type !== IVAR && varName.type !== IMEMBER) {
            throw new Error("expected variable for assignment");
        }
        this.parseVariableAssignmentExpression(varValue);
        instr.push(new Instruction(IVARNAME, varName.value));
        instr.push(new Instruction(IEXPR, varValue));
        instr.push(binaryInstruction("="));
    }
};

ParserState.prototype.parseConditionalExpression = function (instr) {
    this.parseOrExpression(instr);
    while (this.accept(TOP, "?")) {
        var trueBranch = [];
        var falseBranch = [];
        this.parseConditionalExpression(trueBranch);
        this.expect(TOP, ":");
        this.parseConditionalExpression(falseBranch);
        instr.push(new Instruction(IEXPR, trueBranch));
        instr.push(new Instruction(IEXPR, falseBranch));
        instr.push(ternaryInstruction("?"));
    }
};

ParserState.prototype.parseOrExpression = function (instr) {
    this.parseAndExpression(instr);
    while (this.accept(TOP, "or")) {
        var falseBranch = [];
        this.parseAndExpression(falseBranch);
        instr.push(new Instruction(IEXPR, falseBranch));
        instr.push(binaryInstruction("or"));
    }
};

ParserState.prototype.parseAndExpression = function (instr) {
    this.parseComparison(instr);
    while (this.accept(TOP, "and")) {
        var trueBranch = [];
        this.parseComparison(trueBranch);
        instr.push(new Instruction(IEXPR, trueBranch));
        instr.push(binaryInstruction("and"));
    }
};

var COMPARISON_OPERATORS = ["==", "!=", "<", "<=", ">=", ">", "in"];

ParserState.prototype.parseComparison = function (instr) {
    this.parseAddSub(instr);
    while (this.accept(TOP, COMPARISON_OPERATORS)) {
        var op = this.current;
        this.parseAddSub(instr);
        instr.push(binaryInstruction(op.value));
    }
};

var ADD_SUB_OPERATORS = ["+", "-", "||"];

ParserState.prototype.parseAddSub = function (instr) {
    this.parseTerm(instr);
    while (this.accept(TOP, ADD_SUB_OPERATORS)) {
        var op = this.current;
        this.parseTerm(instr);
        instr.push(binaryInstruction(op.value));
    }
};

var TERM_OPERATORS = ["*", "/", "%"];

ParserState.prototype.parseTerm = function (instr) {
    this.parseFactor(instr);
    while (this.accept(TOP, TERM_OPERATORS)) {
        var op = this.current;
        this.parseFactor(instr);
        instr.push(binaryInstruction(op.value));
    }
};

ParserState.prototype.parseFactor = function (instr) {
    var { unaryOps } = this.tokens;
    function isPrefixOperator(token) {
        return token.value in unaryOps;
    }

    this.save();
    if (this.accept(TOP, isPrefixOperator)) {
        if (this.current.value !== "-" && this.current.value !== "+") {
            if (this.nextToken.type === TPAREN && this.nextToken.value === "(") {
                this.restore();
                this.parseExponential(instr);
                return;
            } else if (this.nextToken.type === TSEMICOLON || this.nextToken.type === TCOMMA || this.nextToken.type === TEOF || (this.nextToken.type === TPAREN && this.nextToken.value === ")")) {
                this.restore();
                this.parseAtom(instr);
                return;
            }
        }

        var op = this.current;
        this.parseFactor(instr);
        instr.push(unaryInstruction(op.value));
    } else {
        this.parseExponential(instr);
    }
};

ParserState.prototype.parseExponential = function (instr) {
    this.parsePostfixExpression(instr);
    while (this.accept(TOP, "^")) {
        this.parseFactor(instr);
        instr.push(binaryInstruction("^"));
    }
};

ParserState.prototype.parsePostfixExpression = function (instr) {
    this.parseFunctionCall(instr);
    while (this.accept(TOP, "!")) {
        instr.push(unaryInstruction("!"));
    }
};

ParserState.prototype.parseFunctionCall = function (instr) {
    var { unaryOps } = this.tokens;
    function isPrefixOperator(token) {
        return token.value in unaryOps;
    }

    if (this.accept(TOP, isPrefixOperator)) {
        var op = this.current;
        this.parseAtom(instr);
        instr.push(unaryInstruction(op.value));
    } else {
        this.parseMemberExpression(instr);
        while (this.accept(TPAREN, "(")) {
            if (this.accept(TPAREN, ")")) {
                instr.push(new Instruction(IFUNCALL, 0));
            } else {
                var argCount = this.parseArgumentList(instr);
                instr.push(new Instruction(IFUNCALL, argCount));
            }
        }
    }
};

ParserState.prototype.parseArgumentList = function (instr) {
    var argCount = 0;

    while (!this.accept(TPAREN, ")")) {
        this.parseExpression(instr);
        ++argCount;
        while (this.accept(TCOMMA)) {
            this.parseExpression(instr);
            ++argCount;
        }
    }

    return argCount;
};

ParserState.prototype.parseMemberExpression = function (instr) {
    this.parseAtom(instr);
    while (this.accept(TOP, ".") || this.accept(TBRACKET, "[")) {
        var op = this.current;

        if (op.value === ".") {
            if (!this.allowMemberAccess) {
                throw new Error('unexpected ".", member access is not permitted');
            }

            this.expect(TNAME);
            instr.push(new Instruction(IMEMBER, this.current.value));
        } else if (op.value === "[") {
            if (!this.tokens.isOperatorEnabled("[")) {
                throw new Error('unexpected "[]", arrays are disabled');
            }

            this.parseExpression(instr);
            this.expect(TBRACKET, "]");
            instr.push(binaryInstruction("["));
        } else {
            throw new Error("unexpected symbol: " + op.value);
        }
    }
};
