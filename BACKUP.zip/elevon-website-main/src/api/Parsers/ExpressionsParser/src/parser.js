import { Expression } from "./expression";
import {
    acosh,
    add,
    andOperator,
    arrayFilter,
    arrayFold,
    arrayIndex,
    arrayJoin,
    arrayMap,
    asinh,
    atanh,
    cbrt,
    concat,
    condition,
    cosh,
    div,
    equal,
    expm1,
    factorial,
    gamma,
    greaterThan,
    greaterThanEqual,
    hypot,
    inOperator,
    lessThan,
    lessThanEqual,
    log1p,
    log2,
    log10,
    max,
    min,
    mod,
    mul,
    neg,
    not,
    notEqual,
    orOperator,
    random,
    roundTo,
    setVar,
    sign,
    sinh,
    stringOrArrayIndexOf,
    stringOrArrayLength,
    sub,
    sum,
    tanh,
    trunc
} from "./functions";
import { ParserState } from "./parser-state";
import { TEOF } from "./token";
import { TokenStream } from "./token-stream";

export function Parser(options) {
    this.options = options || {};
    this.unaryOps = {
        sin: Math.sin,
        cos: Math.cos,
        tan: Math.tan,
        asin: Math.asin,
        acos: Math.acos,
        atan: Math.atan,
        sinh: Math.sinh || sinh,
        cosh: Math.cosh || cosh,
        tanh: Math.tanh || tanh,
        asinh: Math.asinh || asinh,
        acosh: Math.acosh || acosh,
        atanh: Math.atanh || atanh,
        sqrt: Math.sqrt,
        cbrt: Math.cbrt || cbrt,
        log: Math.log,
        log2: Math.log2 || log2,
        ln: Math.log,
        lg: Math.log10 || log10,
        log10: Math.log10 || log10,
        expm1: Math.expm1 || expm1,
        log1p: Math.log1p || log1p,
        abs: Math.abs,
        ceil: Math.ceil,
        floor: Math.floor,
        round: Math.round,
        trunc: Math.trunc || trunc,
        "-": neg,
        "+": Number,
        exp: Math.exp,
        not: not,
        length: stringOrArrayLength,
        "!": factorial,
        sign: Math.sign || sign
    };

    this.binaryOps = {
        "+": add,
        "-": sub,
        "*": mul,
        "/": div,
        "%": mod,
        "^": Math.pow,
        "||": concat,
        "==": equal,
        "!=": notEqual,
        ">": greaterThan,
        "<": lessThan,
        ">=": greaterThanEqual,
        "<=": lessThanEqual,
        and: andOperator,
        or: orOperator,
        "in": inOperator,
        "=": setVar,
        "[": arrayIndex
    };

    this.ternaryOps = {
        "?": condition
    };

    this.functions = {
        random: random,
        fac: factorial,
        min: min,
        max: max,
        hypot: Math.hypot || hypot,
        pyt: Math.hypot || hypot, // backward compat
        pow: Math.pow,
        atan2: Math.atan2,
        "if": condition,
        gamma: gamma,
        roundTo: roundTo,
        map: arrayMap,
        fold: arrayFold,
        filter: arrayFilter,
        indexOf: stringOrArrayIndexOf,
        join: arrayJoin,
        sum: sum
    };

    this.consts = {
        E: Math.E,
        PI: Math.PI,
        "true": true,
        "false": false
    };
}

Parser.prototype.parse = function (expr) {
    var instr = [];
    var parserState = new ParserState(
        this,
        new TokenStream(this, expr),
        { allowMemberAccess: this.options.allowMemberAccess }
    );

    parserState.parseExpression(instr);
    parserState.expect(TEOF, "EOF");

    return new Expression(instr, this);
};

Parser.prototype.evaluate = function (expr, variables) {
    return this.parse(expr).evaluate(variables);
};

var sharedParser = new Parser();

Parser.parse = function (expr) {
    return sharedParser.parse(expr);
};

Parser.evaluate = function (expr, variables) {
    return sharedParser.parse(expr).evaluate(variables);
};

var optionNameMap = {
    "+": "add",
    "-": "subtract",
    "*": "multiply",
    "/": "divide",
    "%": "remainder",
    "^": "power",
    "!": "factorial",
    "<": "comparison",
    ">": "comparison",
    "<=": "comparison",
    ">=": "comparison",
    "==": "comparison",
    "!=": "comparison",
    "||": "concatenate",
    "and": "logical",
    "or": "logical",
    "not": "logical",
    "?": "conditional",
    ":": "conditional",
    "=": "assignment",
    "[": "array",
    "()=": "fndef"
};

function getOptionName(op) {
    return optionNameMap.hasOwnProperty(op) ? optionNameMap[op] : op;
}

Parser.prototype.isOperatorEnabled = function (op) {
    var optionName = getOptionName(op);
    var operators = this.options.operators || {};

    return !(optionName in operators) || !!operators[optionName];
};
